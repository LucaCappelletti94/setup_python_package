"""Current version of package setup_python_package."""
__version__ = "1.1.7"