from .is_travis_installed import is_travis_installed
from .is_cwd_a_repository import is_cwd_a_repository

__all__ = [
    "is_travis_installed",
    "is_cwd_a_repository"
]